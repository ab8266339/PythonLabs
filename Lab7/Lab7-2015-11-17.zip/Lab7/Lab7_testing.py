# -*- coding: utf-8 -*-
"""
Created on Tue Nov 17 16:45:41 2015

@author: Hao Xu
"""
import Lab7_countwords
stops()                  
wordCounts('mobydick.txt')
printTop20('mobydick.txt')
similarity('george01.txt','george02.txt','george03.txt','george04.txt')
        